<?xml version="1.0" encoding="UTF-8"?>
<tileset name="instructions" tilewidth="32" tileheight="32">
 <image source="instructions.png" width="640" height="1280"/>
</tileset>
