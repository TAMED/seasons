<?xml version="1.0" encoding="UTF-8"?>
<tileset name="goal" tilewidth="32" tileheight="32">
 <image source="../rocks.png" width="128" height="128"/>
 <tile id="0">
  <properties>
   <property name="type" value="goal"/>
  </properties>
 </tile>
</tileset>
