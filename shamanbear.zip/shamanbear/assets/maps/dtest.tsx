<?xml version="1.0" encoding="UTF-8"?>
<tileset name="dtest" tilewidth="32" tileheight="32">
 <image source="desertTiles.png" width="384" height="512"/>
</tileset>
